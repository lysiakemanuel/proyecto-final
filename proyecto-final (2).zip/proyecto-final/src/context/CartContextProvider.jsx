import { createContext, useEffect, useState } from "react";

export const CartContext = createContext();

const CartContextProvider = (props) => {
  const [products, setProduct] = useState([]);

  const [cart, setCart] = useState([]);
  const readState = async () => {
    const response = await fetch("../../src/db/products.json");
    const data = await response.json();
    localStorage.setItem("products", JSON.stringify(data));
    if (!localStorage.getItem("cart")) {
      localStorage.setItem("cart", "[]");
    }
    setProduct(JSON.parse(localStorage.getItem("products")));
    setCart(JSON.parse(localStorage.getItem("cart")));
  };

  useEffect(() => {
    readState();
  }, []);
  //   useEffect(() => {
  //     localStorage.setItem("items", JSON.stringify(cart));
  //   }, [cart]);

  const addToCart = (id) => {
    const product = products.find((product) => product.id === id);
    if (cart.length === 0) {
      cart.push(product);
    } else {
      const response = cart.find((item) => item.id === id);
      if (response === undefined) {
        cart.push(product);
      }
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    readState();
  };

  const removeFromCart = (id) => {
    const newCart = cart.filter((item) => item.id !== id);
    localStorage.setItem("cart", JSON.stringify(newCart));
    readState();
  };

  const clearCart = () => {
    localStorage.setItem("cart", JSON.stringify([]));
    readState();
  };

  const data = {
    products,
    cart,
    addToCart,
    removeFromCart,
    clearCart,
    readState
  };

  return (
    <CartContext.Provider value={data}>{props.children}</CartContext.Provider>
  );
};

export default CartContextProvider;
