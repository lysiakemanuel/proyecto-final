import Cartitem from "../componets/cartitem/Cartitem";

import { CartContext } from "../context/CartContextProvider";
import { useContext } from "react";

const Cart = () => {
  const data = useContext(CartContext);
  return (
    <div>
      {data.cart.map((item, index) => (
        <Cartitem key={index} item={item} />
      ))}
      <button className="clean-cart" onClick={data.clearCart}>limpiar carrito</button>
    </div>
  );
};

export default Cart;
