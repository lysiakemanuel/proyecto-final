import Productlist from "../componets/productslist/Productlist.jsx";

const Home = () => {
  return (
    <>
      <Productlist />
    </>
  );
};

export default Home;
