import { CartContext } from "../../context/CartContextProvider";
import { useContext} from "react";
import { useParams } from "react-router-dom";

const ItemDetails = () => {
  const data = useContext(CartContext);
  const { id } = useParams();

  const product = data.products.find((product) => product.id === id);

  const { name, price, description, image } = product;
  return (
    <>
      <div>
        <img src={image} />
        <h3>{name}</h3>
        <h4>{price}</h4>
        <p>{description}</p>
        <button onClick={() => data.addToCart(id)}>agregar al carrito</button>
      </div>
    </>
  );
};

export default ItemDetails;
