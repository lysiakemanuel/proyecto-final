
import { NavLink , Link } from "react-router-dom";
import { Container, Item , Title ,  } from "./FooterStyles";
 const Footer = () => {
  return (
    <Container>
      <div>
        <Title>Sigue navegando...</Title>
        <nav>
          <NavLink to="" className="nav-item">
            Inicio
          </NavLink>
          <NavLink to="" className="nav-item">
            Productos
          </NavLink>
        </nav>
      </div>
      <div>
        <Title>Contactanos</Title>
        <ul>
            <Item><Link to=""className="nav-item">whatsap</Link></Item>
            <Item>av siempre viva 123</Item>
            <Item>Lunes a viernes 9 a 18 hs</Item>
        </ul>
      </div>
      <div >
        <Title>siguenos en nuestras redes </Title>
        <ul>
            <Item><Link to=""className="nav-item"><img src="" alt="" />instagram</Link></Item>
            <Item><Link to=""className="nav-item"><img src="" alt="" />x</Link></Item>
            <Item><Link to=""className="nav-item"><img src="" alt="" />Facebook</Link></Item>
        </ul>
      </div>
    </Container>
  );
};

export default Footer;
