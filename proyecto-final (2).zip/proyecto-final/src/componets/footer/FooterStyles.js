import styled from "styled-components";

export const Container = styled.footer`
  background-color: #000000;
  position: fixed; /* Mantiene el footer en la parte inferior */
  bottom: 0; /* Posiciona en la parte inferior */
  left: 0; /* Posiciona a la izquierda */
  width: 100%; /* Ocupa todo el ancho de la página */
  display: flex; /* Distribuye elementos en línea */
  justify-content: space-between; /* Distribuye el contenido */
  align-items: center; /* Alinea verticalmente al centro */
  height: 80px; /* Altura fija para todo el footer */
  padding: 0 20px; /* Espaciado horizontal */

  @media (max-width: 768px) {
    flex-direction: column; /* Cambia a columna en pantallas pequeñas */
    align-items: flex-start; /* Alinea a la izquierda */
    height: auto; /* Permite que la altura se ajuste automáticamente en pantallas pequeñas */
    padding: 15px; /* Ajusta el espaciado */
  }
`;

export const Item = styled.li`
  color: #ffffff;
  list-style: none;
  font-size: 10px; /* Tamaño de fuente uniforme para todos los elementos */
  
  &:hover {
    color: #f0f0f0; /* Cambia el color al pasar el ratón */
    cursor: pointer; /* Cambia el cursor al pasar sobre el elemento */
  }
`;

export const Title = styled.h2`
  color: #ffffff;
  font-size: 14px; /* Tamaño de fuente uniforme para los títulos */

  @media (max-width: 768px) {
    font-size: 14px; /* Mantiene el mismo tamaño en pantallas pequeñas */
  }
`

;

