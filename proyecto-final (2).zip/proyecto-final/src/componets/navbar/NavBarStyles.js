import styled from "styled-components";
export const Container = styled.div`
display:flex;
background-color:#000000;
justify-content:space-between;
align-items:center;
padding:0 2% ;

`
export const NavLogo = styled.img`
width:60px;
`
export const NavMenu = styled.nav`
display:flex;
column-gap:40px;
`
