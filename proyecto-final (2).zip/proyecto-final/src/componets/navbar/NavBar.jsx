import React from "react";
import { Container, NavMenu, NavLogo  } from "./NavBarStyles";
import { NavLink } from "react-router-dom";

const NavBar = () => {
  return (
    <Container>
      <NavLogo src="logo.jpg" alt="" />
      <NavMenu>
        <NavLink to="/" className="nav-item">Inicio</NavLink>
        

        <NavLink to="/cart" className="nav-item">🛒</NavLink>
      </NavMenu>
    </Container>
  );
};

export default NavBar;
