import styled from "styled-components";
export const ProductListContainer = styled.section`
  display: flex;
  justify-content:space-between;
  padding:100px 3%;
`;
