import { CartContext } from "../../context/CartContextProvider";
import { useContext } from "react";
import Product from "../product/Product";
import { ProductListContainer } from "./productListStyles";

const Productlist = () => {
  const data = useContext(CartContext);
  return <ProductListContainer>
    {
        data.products.map(product=> <Product key={product.id} product={product}/>)
    }
    
  </ProductListContainer>;
};

export default Productlist;
