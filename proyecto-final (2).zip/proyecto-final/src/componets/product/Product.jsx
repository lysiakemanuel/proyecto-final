
import { Link } from "react-router-dom";
import { ProductCard ,CardImage,CardButton} from "./productStyles";
const Product = (props) => {
   
    const{name,price,id,image} = props.product
  return (
    <ProductCard >
      <CardImage src={image}/ >
      <h3>{name}</h3>
      <h4>{price}</h4>
      <Link to={`/detail/${id}`}> 
      <CardButton >ver detalles</CardButton>
      </Link>
      
    </ProductCard>
  );
};

export default Product;
