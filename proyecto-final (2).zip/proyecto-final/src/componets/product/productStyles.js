import styled from "styled-components";
export const ProductCard = styled.div`
  border: 1px solid black;
  color: black;
  display:flex;
  flex-direction:column;
  align-items:center;
  padding:10px;
`;

export const CardImage = styled.img`
  width: 200px;
  height: 200px;
  object-fit: contain;
`;
export const CardButton = styled.button`
  border: 2px solid lightgreen;
  color:lightgreen;
  border-radius:20px;
  padding:10px 20px;
  background-color:transparent;
  
`;