import { CartContext } from "../../context/CartContextProvider";
import { useContext } from "react";
import { ItemCard, CardButton, CardImage } from "./cartItemStyles";

const Cartitem = ({ item }) => {
  const data = useContext(CartContext);
  const { name, price, id, image } = item;
  return (
    <ItemCard>
      <CardImage src={image} alt="" />
      <h3>{name}</h3>
      <h4>${price}</h4>
      <CardButton onClick={() => data.removeFromCart(id)}>eliminar</CardButton>
    </ItemCard>
  );
};

export default Cartitem;
