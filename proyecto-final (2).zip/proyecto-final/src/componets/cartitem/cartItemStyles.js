import styled from "styled-components";
export const ItemCard = styled.div`
  display:flex;
  align-items:center;
  width:70%;
  border: 2px solid black;
  justify-content:space-around;
`;

export const CardImage = styled.img`
  width: 150px;
  height: 150px;
  object-fit: contain;
`;
export const CardButton = styled.button`
  border: 2px solid red;
  color:red;
  border-radius:20px;
  padding:10px 20px;
  background-color:transparent;
  
`;
