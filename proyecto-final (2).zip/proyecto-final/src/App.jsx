import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/Home";
import CartContextProvider from "./context/CartContextProvider";
import Cart from "./pages/Cart";
import ItemDetails from "./componets/item_details/ItemDetails";
import NavBar from "./componets/NavBar/NavBar";
import Footer from "./componets/footer/Footer";

function App() {
  return (
    <>
      <CartContextProvider>
        <BrowserRouter>
        <NavBar/>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/detail/:id" element={<ItemDetails/>} />
            <Route path="/cart" element={<Cart/>} />
          </Routes>
          <Footer/>
        </BrowserRouter>
      </CartContextProvider>
    </>
  );
}

export default App;
